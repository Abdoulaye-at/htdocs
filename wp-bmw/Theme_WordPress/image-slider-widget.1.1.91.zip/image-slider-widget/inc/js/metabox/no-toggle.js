jQuery(document).ready(function() {
	
	jQuery('.postbox h3, .postbox .handlediv').unbind('click.postboxes');
	
});